module.exports = {
  coinCount
}

// accepts coin denomination value, returns true if value is a valid coin
const validDenomination = (coin) => [1, 5, 10, 25, 50, 100].indexOf(coin) !== -1;

// accepts coin object, returns value of coin object
const valueFromCoinObject = (obj) => {
  const { denom = 0, count = 0 } = obj;
  return denom * count;
};

/* let halfDollar = { denom: 50, count: 3 };
let penny = { denom: 1, count: 7 };
let nickel = { denom: 5, count: 4 };
let dime = { denom: 10, count: 2 };
let quarter = { denom: 25, count: 1 };
let dollar = { denom: 100, count: 5 };

const coins = [halfDollar, penny, nickel, dime, quarter, dollar]; */

//const coinArray = [coin, coin2];

// accepts array of coin objects, returns total value of all coin objects
const valueFromArray = (arr) => {
  // tests for array within array, should work for extra credit
  if (Array.isArray(arr[0])) {
    return arr[0].reduce((total, num) => total + valueFromCoinObject(num), 0);
  }
  return arr.reduce((total, num) => total + valueFromCoinObject(num), 0);
}

//console.log(valueFromArray(coinArray));

//Accepts coin objects as the parameter, returns value of coin objects
function coinCount(...coinage) {
  return valueFromArray(coinage);
}

/* console.log("{}", coinCount({denom: 5, count: 3}));
console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
console.log("...[{}]", coinCount(...coins));
console.log("[{}]", coinCount(coins)); */

//console.log(coins);