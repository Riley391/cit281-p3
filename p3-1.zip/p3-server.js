const fs = require("fs");
const fastify = require("fastify")();
const { coinCount } = require('./p3-module.js')

fastify.get("/", (request, reply) => {
  // I could not get readFile to work, not sure what I was doing wrong.
  // UPDATE: Figured it out, so ignore the stream solution
  const path = __dirname + "\\index.html";

  fs.readFile(path, (err, data) => {
    if (err) {
      reply
        .code(500);
    }
    else {
      reply
        .code(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .send(data);
    }
  })
  
  // I found another way to reply with an html file using streams
  /* const stream = fs.createReadStream('./index.html');
  reply
    .code(200)
    .type('text/html')
    .send(stream); */
});

fastify.get("/coin", (request, reply) => {
  let { denom=0, count=0 } = request.query;
  denom = parseInt(denom);
  count = parseInt(count);
  const coin = { denom, count };

  const result = coinCount(coin);

  reply
    .code(200)
    .header("Content-Type", "text/html; charset=utf-8")
    .send(`<h2>Value of ${count} of ${denom} is ${result}</h2><br/><a href="/">Home</a>`);
});

fastify.get("/coins", (request, reply) => {
  let { option } = request.query;
  const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
  let result;

  switch (parseInt(option)) {
    case 1:
      result = coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 });
      break;
    case 2:
      result = coinCount(...coins);
      break;
    case 3:
      result = coinCount(coins);
      break;
    default:
      result = 0;
  }

  reply
    .code(200)
    .header("Content-Type", "text/html; charset=utf-8")
    .send(`<h2>Option ${option} value is ${result}</h2><br/><a href="/">Home</a>`);
});

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
});

// console.log(`${__dirname}\\index.html`);